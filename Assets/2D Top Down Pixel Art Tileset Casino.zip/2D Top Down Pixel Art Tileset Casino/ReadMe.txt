
THANK YOU FOR DOWNLOADING THIS ASSET!
_____________________________________________________________________________________________________________

My name is Jeremy, but I usually go by the alias: Jephed. 


CREDITS & USAGE
_____________________________________________________________________________________________________________

The Top Down Pixel Art Casino Tileset is free for commercial and non-commercial use.
When using this asset, credits you can credit me by adding the following to your credits list:
Jephed, Game Between The Lines, https://gamebetweenthelines.com/


CONTACT INFORMATION
_____________________________________________________________________________________________________________

Do you have a question about this asset?

You can reach me via the following platforms:
* Itch.io     | https://gamebetweenthelines.itch.io/
* X (Twitter) | https://twitter.com/Jephed_
* YouTube     | https://www.youtube.com/@Jephed_
* E-mail      | jephed@gamebetweenthelines.com